#include "transpose.h"

/* La fonction de transposition naïve. */
void transpose_naive(int n, int blocksize, int *dst, int *src) {
    for (int x = 0; x < n; x++) {
        for (int y = 0; y < n; y++) {
            dst[y + x * n] = src[x + y * n];
        }
    }
}

/* Implémentez ci-dessous la technique du cache-blocking.  
 * REMARQUE : La dimension 'n' de la matrice n'est pas 
 * nécessairement multiple de 'blocksize' (la taille du bloc). */
void transpose_blocking(int n, int blocksize, int *dst, int *src) {

    /* VOTRE SOLUTION ICI */

}
