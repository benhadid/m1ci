#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>


/* Nous incluons ici les 6 variantes de l'ordre des boucles en tant que 
   fonctions séparées, puis les appelons à l'aide de pointeurs de fonction. 
   La raison d'avoir des fonctions séparées qui sont presque identiques est 
   d'éviter de compter tout traitement superflu dans le temps de calcul. 
   Cela inclut les accès E / S (printf) et les conditions (if / switch). 
   Les accès d'E / S sont lents et les instructions conditionnelles / de branchement 
   peuvent fausser les résultats.
*/
void multMat1( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* Ceci est l'ordre ijk des boucles */
    for( i = 0; i < n; i++ )
        for( j = 0; j < n; j++ )
            for( k = 0; k < n; k++ )
                C[i*n+j] += A[i*n+k]*B[k*n+j];
}

void multMat2( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* Ceci est l'ordre ikj des boucles */    
    for( i = 0; i < n; i++ )
        for( k = 0; k < n; k++ )
            for( j = 0; j < n; j++ )
                C[i+j*n] += A[i+k*n]*B[k+j*n];
}

void multMat3( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* Ceci est l'ordre jik des boucles */    
    for( j = 0; j < n; j++ )
        for( i = 0; i < n; i++ )
            for( k = 0; k < n; k++ )
                C[i+j*n] += A[i+k*n]*B[k+j*n];
}

void multMat4( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* Ceci est l'ordre jki des boucles */    
    for( j = 0; j < n; j++ )
        for( k = 0; k < n; k++ )
            for( i = 0; i < n; i++ )
                C[i+j*n] += A[i+k*n]*B[k+j*n];
}

void multMat5( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* Ceci est l'ordre kij des boucles */    
    for( k = 0; k < n; k++ )
        for( i = 0; i < n; i++ )
            for( j = 0; j < n; j++ )
                C[i+j*n] += A[i+k*n]*B[k+j*n];
}

void multMat6( int n, float *A, float *B, float *C ) {
    int i,j,k;
    /* Ceci est l'ordre kji des boucles */    
    for( k = 0; k < n; k++ )
        for( j = 0; j < n; j++ )
            for( i = 0; i < n; i++ )
                C[i+j*n] += A[i+k*n]*B[k+j*n];
}

/* utilise les fonctionnalités de chronométrage dans sys/time.h */
int main( int argc, char **argv ) {
    int nmax = 1000,i;

    void (*orderings[])(int,float *,float *,float *) =
        {&multMat1,&multMat2,&multMat3,&multMat4,&multMat5,&multMat6};
    char *names[] = {"ijk","ikj","jik","jki","kij","kji"};

    float *A = (float *)malloc( nmax*nmax * sizeof(float));
    float *B = (float *)malloc( nmax*nmax * sizeof(float));
    float *C = (float *)malloc( nmax*nmax * sizeof(float));

    struct timeval start, end;

    /* remplir les matrices avec des nombres aléatoires */    
    for( i = 0; i < nmax*nmax; i++ ) A[i] = drand48()*2-1;
    for( i = 0; i < nmax*nmax; i++ ) B[i] = drand48()*2-1;
    for( i = 0; i < nmax*nmax; i++ ) C[i] = drand48()*2-1;

    for( i = 0; i < 6; i++) {
        /* multiplie les matrices et mesure le temps d'exécution */
        gettimeofday( &start, NULL );
        (*orderings[i])( nmax, A, B, C );
        gettimeofday( &end, NULL );

        /* convertir le temps mesuré en Gflop/s */
        double seconds = (end.tv_sec - start.tv_sec) +
            1.0e-6 * (end.tv_usec - start.tv_usec);
        double Gflops = 2e-9*nmax*nmax*nmax/seconds;
        printf( "%s:\tn = %d, %.3f Gflop/s\n", names[i], nmax, Gflops );
    }

    free( A );
    free( B );
    free( C );

    printf("\n\n");

    return 0;
}
