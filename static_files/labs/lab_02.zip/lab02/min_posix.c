#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <pthread.h>

#define ARRAY_SIZE  50000000
#define NUM_THREADS 4

int *array;

int val=1000;

pthread_mutex_t lock_val;

void* min_thread(void* arg)
{
    //TODO: Implémentez le corp de la fonction min_thread() pour trouver le minimum du tableau 'array' 
    //      et l'inscrire dans la variable global 'val'
    //  paramètres en entrée : arg (Indice du thread)
    //  paramètres en sortie : aucun
    int tid = *((int *)arg);
    // BLOC_DEBUT
    fprintf(stderr,"Erreur : Fonction 'min_thread()' non implémentée !\n");
    // BLOC_FIN

    pthread_exit(NULL);
}

int min() {
    /* création des threads de l'application */
    pthread_t threadid[NUM_THREADS];
    int rc;

    for(int i=0; i<NUM_THREADS; ++i) {
       int param = i;         
       rc = pthread_create(&threadid[i], NULL, min_thread, &param);       
       if( 0 !=rc ) {
           fprintf(stderr, "Erreur : 'pthread_create()' a échouée, rc: %d\n", rc);
           return EXIT_FAILURE;
       }
    }

    /* block until all threads complete */
    for (int i = 0; i < NUM_THREADS; ++i) {
       pthread_join(threadid[i], NULL);
    }

    return EXIT_SUCCESS;
}

int main(int argc, char** argv)
{
    /* allocation dynamique de la mémoire pour le tableau 'array' */
    array = (int *) malloc(ARRAY_SIZE * sizeof(int));

    if(NULL==array)
    {
           fprintf(stderr, "Erreur : l'allocation mémoire avec 'malloc' a échouée !\n");
           return EXIT_FAILURE;
    } 

    /* initialisation du tableau 'array' avec des valeurs aléatoires */
    srand48( time( NULL ) );
    for( int i = 0; i < ARRAY_SIZE; ++i ) 
       array[i] = lrand48( ) % 100;

    /*initialisation du mutex associé à la variable 'val'*/
    pthread_mutex_init(&lock_val, NULL);

    /* paramètres pour la mesure de performance */
    struct timeval start, end;

    /*appel de la fonction min()*/
    gettimeofday( &start, NULL );
    min();
    gettimeofday( &end, NULL );

    double seconds = (end.tv_sec - start.tv_sec) +
        1.0e-6 * (end.tv_usec - start.tv_usec);

    /* affichage du résultat */
    printf("mode d'exécution : parallèle\ntemps écoulé = %g millisecondes\n", seconds*1e3);

    /* libérer la mémoire allouée avec malloc() */
    free(array);

    return EXIT_SUCCESS;  
}