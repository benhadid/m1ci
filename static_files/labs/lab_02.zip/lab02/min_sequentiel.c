#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#define ARRAY_SIZE  50000000

int *array;

int val;

void min()
{
    //TODO: Implémentez le corp de la fonction min() qui retourne le minimum du tableau 'array'
    //      paramètres en entrée : aucun (variables globales)
    //      paramètres en sortie : val   (int)
    // BLOC_DEBUT
    fprintf(stderr, "Erreur : Fonction 'min()' non implémentée !\n");
    // BLOC_FIN
}

int main(int argc, char** argv)
{
    /* allocation dynamique de la mémoire pour le tableau 'array' */
    array = (int *) malloc(ARRAY_SIZE * sizeof(int));

    if(NULL==array)
    {
           fprintf(stderr, "Erreur : l'allocation mémoire avec 'malloc' a échouée !\n");
           return EXIT_FAILURE;
    } 

    /* initialisation du tableau 'array' avec des valeurs aléatoires */
    srand48( time( NULL ) );
    for( int i = 0; i < ARRAY_SIZE; ++i ) 
       array[i] = lrand48( ) % 100;

    /* paramètres pour la mesure de performance */
    struct timeval start, end;
    
    val = 1000;

    /*appel de la fonction min()*/
    gettimeofday( &start, NULL );
    min();
    gettimeofday( &end, NULL );

    double seconds = (end.tv_sec - start.tv_sec) +
        1.0e-6 * (end.tv_usec - start.tv_usec);

    /* affichage du résultat */
    printf("Mode d'exécution : séquentiel\ntemps écoulé = %g millisecondes\n", seconds*1e3);

    /* libérer la mémoire allouée avec malloc() */
    free(array);

    return EXIT_SUCCESS;
}