#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <omp.h>

#define A_COLS 1024
#define A_LINES 1024

#define B_COLS 1024
#define B_LINES A_COLS

#define C_COLS B_COLS
#define C_LINES A_LINES

#define ALIGN 4
#define BLOCK_SIZE (ALIGN * 32)

int A_WIDTH;
int B_WIDTH;
int C_WIDTH;

float *A = NULL, *B = NULL, *C = NULL;

typedef float float4_t __attribute__((vector_size(ALIGN * sizeof(float))));

void matmult()
{
    //TODO: Implémentez le corp de la fonction matmult() qui calcul le produit 
    //      matricielle : C = A * B  de façon parallèle (OpenMP) et vectorisée
    // BLOC_DEBUT
    fprintf(stderr,"Erreur : Fonction 'matmult()' non implémentée !\n");
    // BLOC_FIN
}


/***********************
 * Programme principal *
 ***********************/
int main(int argc, char **argv)
{
    A_WIDTH = (((A_COLS - 1) / ALIGN) + 1) * ALIGN;
    int rc = posix_memalign((void **)&A, ALIGN * sizeof(float), A_WIDTH * A_LINES * sizeof(float));
    if (0 != rc)
    {
        fprintf(stderr, "Erreur: posix_memalign() a échoué.\n");
        return EXIT_FAILURE;
    }

    B_WIDTH = (((B_COLS - 1) / ALIGN) + 1) * ALIGN;
    rc = posix_memalign((void **)&B, ALIGN * sizeof(float), B_WIDTH * B_LINES * sizeof(float));
    if (0 != rc)
    {
        fprintf(stderr, "Erreur: posix_memalign() a échoué.\n");
        return EXIT_FAILURE;
    }

    C_WIDTH = B_WIDTH;
    rc = posix_memalign((void **)&C, ALIGN * sizeof(float), C_WIDTH * C_LINES * sizeof(float));
    if (0 != rc)
    {
        fprintf(stderr, "Erreur: posix_memalign() a échoué.\n");
        return EXIT_FAILURE;
    }

    /*****************************************
     * initialisation des matrices A, B et C *
     *****************************************/

    float sa = 1.0 / sqrt((float)(A_COLS));
    float sb = 1.0 / sqrt((float)(B_COLS));

#pragma omp parallel
    {
// Initialisation de la matrice A
#pragma omp for nowait
        for (int i = 0; i < A_LINES; ++i)
        {
            for (int j = 0; j < A_COLS; ++j)
            {
                float angle = 2. * M_PI * i * j / (float)A_COLS;
                A[i * A_WIDTH + j] = sa * (sin(angle) + cos(angle));
            }

            for (int j = A_COLS; j < A_WIDTH; ++j)
            {
                A[i * A_WIDTH + j] = 0;
            }
        }

// Initialisation de la matrice B
#pragma omp for
        for (int i = 0; i < B_LINES; ++i)
        {
            for (int j = 0; j < B_COLS; ++j)
            {
                float angle = 2. * M_PI * i * j / (float)B_COLS;
                B[i * A_WIDTH + j] = sb * (sin(angle) + cos(angle));
            }

            for (int j = B_COLS; j < B_WIDTH; ++j)
            {
                B[i * A_WIDTH + j] = 0;
            }
        }
    }

    // Initialisation de la matrice C à des zéros
    memset(C, 0x0, C_WIDTH * C_LINES * sizeof(float));

    /*********************************
     *    timing de  matmult_v1()    *
     *********************************/
    double wtime = omp_get_wtime();
    matmult();
    double wtimep = omp_get_wtime() - wtime;
    fprintf(stdout, "temps écoulé : %#.5g sec\n", wtimep);
    //fprintf(stdout,"C[90,90] = %g\n", C[90 * C_WIDTH + 90] );

    /************
     * Clean up *
     ************/

    free(A);
    free(B);
    free(C);

    return EXIT_SUCCESS;
}
