//------------------------------------------------------------------------------
//
//  PROGRAM: Matrix Multiplication driver
//
//  PURPOSE: This is a driver program to test various ways of computing
//           the product:
//
//                C  = A * B
//
//           A and B are set to constant matrices so we
//           can make a quick test of the multiplication.
//
//  USAGE:   The matrices are constant matrices, square and the order is
//           set as a constant, ORDER (see mult.h).
//
//  HISTORY: Written by Tim Mattson, August 2010
//           Modified by Simon McIntosh-Smith, September 2011
//           Modified by Tom Deakin and Simon McIntosh-Smith, October 2012
//           Ported to C by Tom Deakin, July 2013
//           Modified to assume square matrices by Simon McIntosh-Smith, Sep 2014
//           Updated to use device picker by Tom Deakin, November 2014
//           Modified by Adnane Benhadid, July 2021
//
//------------------------------------------------------------------------------

#include "matmul.h"
#include "matrix_lib.h"
#include "err_code.h"
#include "device_picker.h"

#define CL_KERNEL_FILE "matmul.cl"

// Load an OpenCL kernel from file
char *readKernelFile(const char *filename, long *_size)
{

    // Open the file
    FILE *file = fopen(filename, "r");
    if (!file)
    {
        printf("-- Error opening file %s\n", filename);
        exit(1);
    }

    // Get its size
    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    rewind(file);

    // Read the kernel code as a string
    char *source = (char *)malloc((size + 1) * sizeof(char));
    fread(source, 1, size * sizeof(char), file);
    source[size] = '\0';
    fclose(file);

    // Save the size and return the source string
    *_size = (size + 1);
    return source;
}

// main program
int main(int argc, char *argv[])
{
    float *h_A;             // A matrix
    float *h_B;             // B matrix
    float *h_C;             // C = A*B matrix
    int M, N, K;            // A[M][K], B[K][N], C[M][N]
    int A_size;             // number of elements in matrix A
    int B_size;             // number of elements in matrix B
    int C_size;             // number of elements in matrix C

    cl_mem d_a, d_b, d_c;   // Matrices in device memory

    double start_time;      // Starting time
    double run_time;        // timing data

    cl_int err;             // error code returned from OpenCL calls
    cl_device_id     device;        // compute device id
    cl_context       context;       // compute context
    cl_command_queue commands;      // compute command queue
    cl_program       program;       // compute program
    cl_kernel        kernel;        // compute kernel

    //TODO-BLOC-DEBUT : Afin de tester votre programme, modifier les valeurs de M,N et K pour des matrices non carrées
    M    = ORDER;
    N    = ORDER;
    K    = ORDER;
    //TODO-BLOC-FIN.

    A_size = M * K;
    B_size = K * N;
    C_size = M * N;
 
    h_A = (float *)malloc(A_size * sizeof(float));
    h_B = (float *)malloc(B_size * sizeof(float));
    h_C = (float *)malloc(C_size * sizeof(float));

//--------------------------------------------------------------------------------
// Create a context, queue and device.
//--------------------------------------------------------------------------------

    cl_uint deviceIndex = 0;
    parseArguments(argc, argv, &deviceIndex);

    // Get list of devices
    cl_device_id devices[MAX_DEVICES];
    unsigned numDevices = getDeviceList(devices);

    // Check device index in range
    if (deviceIndex >= numDevices)
    {
      printf("Invalid device index (try '--list')\n");
      return EXIT_FAILURE;
    }

    device = devices[deviceIndex];

    char name[MAX_INFO_STRING];
    getDeviceName(device, name);
    printf("\nUsing OpenCL device: %s\n", name);

    // Create a compute context
    context = clCreateContext(0, 1, &device, NULL, NULL, &err);
    checkError(err, "Creating context");

   // Create a command queue
    commands = clCreateCommandQueue(context, device, 0, &err);
    checkError(err, "Creating command queue");


//--------------------------------------------------------------------------------
// Run sequential version on the host
//--------------------------------------------------------------------------------

    initmat(M, N, K, h_A, h_B, h_C);

    printf("\n===== OpenMP, matrix mult (dot prod), order (%d,%d)x(%d,%d) on host CPU ======\n", M, K, K, N);
    for(int i = 0; i < COUNT; i++)
    {
        zero_mat(M, N, h_C);
        start_time = wtime();

        omp_mat_mul_sdot(M, N, K, h_A, h_B, h_C);

        run_time  = wtime() - start_time;
        results(M, N, K, h_C, run_time);
    }


//--------------------------------------------------------------------------------
// Setup the buffers, initialize matrices, and write them into global memory
//--------------------------------------------------------------------------------

    //  Reset A, B and C matrices (just to play it safe)
    initmat(M, N, K, h_A, h_B, h_C);

    d_a = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
                            sizeof(float) * A_size, h_A, &err);
    checkError(err, "Creating buffer d_a");

    d_b = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
                            sizeof(float) * B_size, h_B, &err);
    checkError(err, "Creating buffer d_b");

    d_c = clCreateBuffer(context, CL_MEM_WRITE_ONLY,
                            sizeof(float) * C_size, NULL, &err);
    checkError(err, "Creating buffer d_c");


//--------------------------------------------------------------------------------
// OpenCL matrix multiplication ... Naive
//--------------------------------------------------------------------------------

    // Read the kernel file from disk
    long sizeSource;
    char* source = readKernelFile(CL_KERNEL_FILE, &sizeSource);

    // Create the comput program from the source buffer
    program = clCreateProgramWithSource(context, 1, (const char **) &source, NULL, &err);
    checkError(err, "Creating program");

   // Build the program
    err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
    if (err != CL_SUCCESS)
    {
        size_t len;
        char buffer[2048];

        printf("Error: Failed to build program executable!\n%s\n", err_code(err));
        clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG, sizeof(buffer), buffer, &len);
        printf("%s\n", buffer);
        return EXIT_FAILURE;
    }

    // Create the compute kernel from the program
    kernel = clCreateKernel(program, "mmul16", &err);
    checkError(err, "Creating kernel");

    printf("\n===== OpenCL, matrix mult, C(i,j) per work item, order %d ======\n",N);

    // Do the multiplication COUNT times
    for (int i = 0; i < COUNT; i++)
    {
        zero_mat(M, N, h_C);

        //TODO-BLOC-DEBUT : modifications à faire pour rendre le code compatible avec des matrices non carrées

        err =  clSetKernelArg(kernel, 0,       sizeof(int),    &N);
        err |= clSetKernelArg(kernel, 1,       sizeof(cl_mem), &d_a);
        err |= clSetKernelArg(kernel, 2,       sizeof(cl_mem), &d_b);
        err |= clSetKernelArg(kernel, 3,       sizeof(cl_mem), &d_c);


        checkError(err, "Setting kernel arguments");

        start_time = wtime();

        // Execute the kernel over the entire range of C matrix elements ... computing
        // a dot product for each element of the product matrix.  The local work
        // group size is set to NULL ... so I'm telling the OpenCL runtime to
        // figure out a local work group size for me.
        const size_t global[2] = {N, N};
        const size_t local[2] = {16, 16};

        err = clEnqueueNDRangeKernel(
            commands,
            kernel,
            2,
            NULL,
            global,
            local,
            0,
            NULL,
            NULL);

        checkError(err, "Enqueuing kernel");

        //TODO-BLOC-FIN.


        err = clFinish(commands);
        checkError(err, "Waiting for commands to finish");

        run_time = wtime() - start_time;

        err = clEnqueueReadBuffer(
            commands, d_c, CL_TRUE, 0,
            sizeof(float) * C_size, h_C,
            0, NULL, NULL);
        checkError(err, "Reading back buffer d_c");

        results(M, N, K, h_C, run_time);

    } // end for loop


//--------------------------------------------------------------------------------
// Clean up!
//--------------------------------------------------------------------------------

    free(h_A);
    free(h_B);
    free(h_C);
    clReleaseMemObject(d_a);
    clReleaseMemObject(d_b);
    clReleaseMemObject(d_c);
    clReleaseProgram(program);
    clReleaseKernel(kernel);
    clReleaseCommandQueue(commands);
    clReleaseContext(context);

    return EXIT_SUCCESS;
}


