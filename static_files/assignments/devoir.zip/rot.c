#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<omp.h>


void rot(int N, double* arr) {
  for (int i = 0; i < N - 1; i++) {
    double tmp = arr[i];
    arr[i] = arr[i+1];
    arr[i+1] = tmp;
  }
}

int main(int argc, char ** argv) {
  if (argc != 2) {
    printf("Usage: %s <N>\n", argv[0]);
    return EXIT_SUCCESS;
  }
  int N = atoi(argv[1]);
  double* a = malloc(N * sizeof(double));
  for (int i = 0; i < N; i++) a[i] = i;
  double start = omp_get_wtime();
  rot(N, a);
  double end = omp_get_wtime();
  double error = 0;
  for (int i = 0; i < N; i++) error += fabs(a[i] - (i + 1) % N);
  printf("elapsed: %f, error: %f\n", end - start, error);
}
